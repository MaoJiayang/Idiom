package com.nucleon;
import java.io.File;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class JsonToAccess {

    public static void main(String[] args) {
        Gson commongson = new Gson();
        File commonfile = new File("C:/Users/82660/Desktop/JsonToAccess/src/main/resources/common_idiom.json");
        try {
            List<Idiom> idioms = commongson.fromJson(new FileReader(commonfile), new TypeToken<List<Idiom>>(){}.getType());

            String databaseFilePath = "C:/Users/82660/Documents/idiom.accdb";
            String url = "jdbc:ucanaccess://" + databaseFilePath;

            try(Connection conn = DriverManager.getConnection(url);
                PreparedStatement pstmt = conn.prepareStatement("INSERT INTO CommonIdiom (Word, Pinyin, Abbreviation, Explanation, Example, Derivation) VALUES (?, ?, ?, ?, ?, ?)")) {

                for(Idiom idiom : idioms) {
                    pstmt.setString(1, idiom.getWord());
                    pstmt.setString(2, idiom.getPinyin());
                    pstmt.setString(3, idiom.getAbbreviation());
                    pstmt.setString(4, idiom.getExplanation());
                    pstmt.setString(5, idiom.getExample());
                    pstmt.setString(6, idiom.getDerivation());
                    pstmt.executeUpdate();
                }
            } catch(SQLException e) {
                e.printStackTrace();
            }

        } catch(Exception e) {
            e.printStackTrace();
        }
        System.out.println("common程序已结束");
        Gson idiomgson = new Gson();
        File idiomfile = new File("C:/Users/82660/Desktop/JsonToAccess/src/main/resources/idiom.json");
        try {
            List<Idiom> idioms = idiomgson.fromJson(new FileReader(idiomfile), new TypeToken<List<Idiom>>(){}.getType());

            String databaseFilePath = "C:/Users/82660/Documents/idiom.accdb";
            String url = "jdbc:ucanaccess://" + databaseFilePath;

            try(Connection conn = DriverManager.getConnection(url);
                PreparedStatement pstmt = conn.prepareStatement("INSERT INTO Idiom (Word, Pinyin, Abbreviation, Explanation, Example, Derivation) VALUES (?, ?, ?, ?, ?, ?)")) {

                for(Idiom idiom : idioms) {
                    pstmt.setString(1, idiom.getWord());
                    pstmt.setString(2, idiom.getPinyin());
                    pstmt.setString(3, idiom.getAbbreviation());
                    pstmt.setString(4, idiom.getExplanation());
                    pstmt.setString(5, idiom.getExample());
                    pstmt.setString(6, idiom.getDerivation());
                    pstmt.executeUpdate();
                }
            } catch(SQLException e) {
                e.printStackTrace();
            }

        } catch(Exception e) {
            e.printStackTrace();
        }
        System.out.println("idiom程序已结束");
    }
}