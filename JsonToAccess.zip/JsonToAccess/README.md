﻿# Idiom
成语接龙java大作业
20230603
Idiom.json和common_idiom.json导入Access数据库
请注意调用时要填写文件的绝对路径